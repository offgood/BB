# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError


class Request2Purchase(models.TransientModel):
    _name = 'sr_pr.request.convert'
    _description = 'Create new or use existing Customer on new Quotation'

    @api.model
    def default_get(self, fields):
        result = super(Request2Purchase, self).default_get(fields)

        active_model = self._context.get('active_model')
        if active_model != 'sr_pr.request':
            raise UserError(_('You can only apply this action from a request.'))

        request = False
        if result.get('ref_name'):
            request = self.env['sr_pr.request'].browse(result['ref_name'])
        elif 'ref_name' in fields and self._context.get('active_id'):
            request = self.env['sr_pr.request'].browse(self._context['active_id'])
        if request:
            result['ref_name'] = request.id
            project_id = result.get('project_id') or request._find_matching_partner().id
            if 'action' in fields and not result.get('action'):
                result['action'] = 'exist' if project_id else 'create'
            if 'project_id' in fields and not result.get('project_id'):
                result['project_id'] = project_id

        return result

    ref_name = fields.Many2one('sr_pr.request', 'Ref:', required=True)
    project_id = fields.Many2one('project.project', 'Project')

    def action_apply(self):
        """ Convert lead to opportunity or merge lead and opportunity and open
            the freshly created opportunity view.
        """
        self.ensure_one()
        if self.action != 'nothing':
            self.ref_name.handle_partner_assignment(force_partner_id=self.project_id.id, create_missing=(self.action == 'create'))
        return self.ref_name.action_new_quotation()
 