from pickletools import uint1
from odoo import models, fields, api

class RequestOrderline(models.Model):
    _name = 'sr.orderline'
    _description = 'Request Orderline'
    
    
    product_id = fields.Many2one('product.product', 'Product')
    ref_id = fields.Many2one('sr_pr.request', string='Reference', ondelete='cascade', copy=False)
    unit = fields.Float('Unit',tracking=True)
    delivery_date = fields.Date(string='Delivery Date')
    name = fields.Text(string='Notes')
    product_type = fields.Char(string='Model/Series')
    product_template_id = fields.Many2one('product.template',compute='_compute_product_type',tracking=True)
    display_type = fields.Selection([
        ('line_section', "Section"),
        ('line_note', "Note")], default=False, help="Technical field for UX purpose.")
    address = fields.Selection([
        ('office', 'สำนักงานใหญ่'),
        ('store', 'สโตร์'),
        ('site', 'หน้างาน'),
        ],string='Delivery to',track_visibility='onchange', tracking=True)
    delivery_site = fields.Char(string='ระบุสถานที่')
 
