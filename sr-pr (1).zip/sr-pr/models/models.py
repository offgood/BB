# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class sr-pr(models.Model):
#     _name = 'sr-pr.sr-pr'
#     _description = 'sr-pr.sr-pr'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
